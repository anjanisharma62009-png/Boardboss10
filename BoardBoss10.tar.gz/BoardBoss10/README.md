# 📱 BoardBoss10 - CBSE Class 10 Quiz Battle App

## 🎯 Overview

**BoardBoss10** is a complete Android quiz application for CBSE Class 10 students featuring:
- **Subjects**: Maths, Science, SST, English, Hindi
- **Admin User**: Anjani
- **Location**: Uttar Pradesh, India
- **Educational Level**: CBSE Class 10

---

## ✨ Key Features

### 🔐 User Authentication
- Username-based login system
- Admin detection (username: "Anjani", case-insensitive)
- Location tracking
- Persistent session management

### 🎮 Quiz System
- Live quiz battles with countdown timer
- Default timer: 30 seconds per question
- 10 questions per quiz
- 4 multiple-choice options
- Smart scoring: `basePoints * (1 + speedBonus)`
- Speed bonus calculation: `(timerDuration - timeSpent) / timerDuration`
- No negative marking

### 👑 Admin Panel
- Load 15+ sample questions (all subjects)
- View all users and questions
- App statistics dashboard
- Question management
- User management

### 🏆 Features
- ✅ Dark mode support (enabled by default)
- ✅ Daily challenges (enabled)
- ✅ Leaderboards (enabled)
- ✅ Max 10 players per room
- ✅ Bilingual support
- ✅ Primary color: #6B4EFF

---

## 🚀 Quick Start

### Prerequisites
1. Android Studio Arctic Fox or later
2. JDK 8 or higher
3. Android SDK 24+ (minimum)
4. Firebase account

### Firebase Setup

1. **Create Firebase Project**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Create new project: "BoardBoss10"
   - Enable Google Analytics (optional)

2. **Add Android App**
   - Package name: `com.company.boardboss10`
   - Download `google-services.json`
   - Place in `app/` directory

3. **Enable Firebase Services**
   ```
   Authentication → Sign-in method → Anonymous (Enable)
   Realtime Database → Create Database → Start in test mode
   ```

4. **Database Security Rules** (For Production)
   ```json
   {
     "rules": {
       "users": {
         "$uid": {
           ".read": true,
           ".write": "$uid === auth.uid"
         }
       },
       "questions": {
         ".read": true,
         ".write": "root.child('users').child(auth.uid).child('isAdmin').val() === true"
       },
       "rooms": {
         ".read": true,
         ".write": true
       },
       "results": {
         ".read": true,
         ".write": true
       }
     }
   }
   ```

### Building the App

1. **Clone/Open Project**
   ```bash
   cd BoardBoss10
   ```

2. **Add google-services.json**
   - Place your Firebase config file in `app/` directory

3. **Build Project**
   ```bash
   ./gradlew build
   ```

4. **Run on Device/Emulator**
   ```bash
   ./gradlew installDebug
   ```

---

## 👤 Admin Access

- **Admin Username**: Anjani (case-insensitive)
- **Location**: Any (e.g., "Uttar Pradesh, India")

On first login as "Anjani":
1. Admin privileges automatically granted
2. Floating Admin button appears on home screen
3. Access admin panel to load sample questions

### Loading Sample Questions

1. Login as admin (username: "Anjani")
2. Tap Admin button (floating action button)
3. Click "Load Sample Questions"
4. 15 questions loaded across all subjects

---

## 📚 Sample Questions Included

- **Maths**: 3 questions (Algebra, Geometry, Trigonometry)
- **Science**: 3 questions (Physics, Chemistry, Biology)
- **SST**: 3 questions (History, Geography, Civics)
- **English**: 2 questions (Grammar, Vocabulary)
- **Hindi**: 2 questions (व्याकरण, साहित्य)
- **Additional**: 2 mixed questions

---

## 🎨 Customization

### Colors
- Primary: #6B4EFF (from user preferences)
- Accent: #FF6B9D
- Background: Dynamic (light/dark mode)

### Timer Settings
- Default: 30 seconds
- Options: 30s or 60s per question

### Room Settings
- Max players: 10 (configurable)
- Questions per quiz: 10 (default)

---

## 📱 App Structure

```
BoardBoss10/
├── app/src/main/
│   ├── java/com/company/boardboss10/
│   │   ├── data/          # Repositories
│   │   ├── models/        # Data models
│   │   ├── ui/            # Activities & Fragments
│   │   └── utils/         # Helper classes
│   └── res/
│       ├── layout/        # XML layouts
│       ├── values/        # Colors, strings, themes
│       ├── menu/          # Navigation menu
│       └── navigation/    # Nav graph
```

---

## 🔧 Technical Stack

- **Language**: Kotlin 100%
- **Architecture**: MVVM with Repository pattern
- **Database**: Firebase Realtime Database
- **Auth**: Firebase Anonymous Authentication
- **UI**: Material Design 3, ViewBinding
- **Async**: Kotlin Coroutines
- **Navigation**: Jetpack Navigation Component
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)

---

## 🐛 Troubleshooting

### Build Errors

**Error: google-services.json not found**
```
Solution: Download from Firebase Console and place in app/ directory
```

**Error: Firebase dependencies**
```bash
Solution: File → Invalidate Caches → Restart
```

### Runtime Errors

**Error: Database permission denied**
```
Solution: Check Firebase Realtime Database rules (set to test mode)
```

**Error: Questions not loading**
```
Solution: Login as admin and load sample questions first
```

---

## 📞 Support

For questions or issues:
1. Check Firebase configuration
2. Verify database rules
3. Ensure internet connection
4. Check logcat for errors

---

## 📄 License

This project is created for educational purposes for CBSE Class 10 students.

---

**Generated by CREAO Android Quiz App Builder**
