# Add project specific ProGuard rules here.
# Firebase
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Keep data models
-keep class com.company.boardboss10.models.** { *; }

# Kotlin
-dontwarn kotlin.**
-keep class kotlin.** { *; }

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
