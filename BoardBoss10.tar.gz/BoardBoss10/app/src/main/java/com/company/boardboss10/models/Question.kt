package com.company.boardboss10.models

/**
 * Question data model for quiz content
 * Supports multiple subjects: Maths, Science, SST, English, Hindi
 */
data class Question(
    val questionId: String = "",
    val subject: String = "", // Maths, Science, SST, English, Hindi
    val chapter: String = "",
    val questionText: String = "",
    val options: List<String> = emptyList(), // Always 4 options
    val correctAnswer: Int = 0, // Index: 0-3
    val difficulty: String = "Medium", // Easy, Medium, Hard
    val explanation: String = "",
    val points: Int = 10, // Base points for this question
    val isActive: Boolean = true,
    val createdBy: String = "", // Admin username
    val createdAt: Long = System.currentTimeMillis()
) {
    // Validation helper
    fun isValid(): Boolean {
        return questionText.isNotBlank() &&
               options.size == 4 &&
               correctAnswer in 0..3 &&
               subject.isNotBlank()
    }
}
