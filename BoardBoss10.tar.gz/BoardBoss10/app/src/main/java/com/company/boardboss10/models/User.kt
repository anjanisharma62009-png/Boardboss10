package com.company.boardboss10.models

/**
 * User data model representing a quiz app user
 * Supports admin detection, location tracking, and comprehensive statistics
 */
data class User(
    val userId: String = "",
    val username: String = "",
    val isAdmin: Boolean = false,
    val location: String = "", // Location: Uttar Pradesh, India
    val educationalLevel: String = "CBSE Class 10",

    // Score tracking
    val totalScore: Int = 0,
    val dailyScore: Int = 0,
    val weeklyScore: Int = 0,
    val monthlyScore: Int = 0,

    // Subject-wise scores
    val mathsScore: Int = 0,
    val scienceScore: Int = 0,
    val sstScore: Int = 0,
    val englishScore: Int = 0,
    val hindiScore: Int = 0,

    // Engagement metrics
    val streak: Int = 0,
    val badges: List<String> = emptyList(),
    val gamesPlayed: Int = 0,
    val questionsAnswered: Int = 0,
    val correctAnswers: Int = 0,

    // Timestamps
    val createdAt: Long = System.currentTimeMillis(),
    val lastActive: Long = System.currentTimeMillis()
)
