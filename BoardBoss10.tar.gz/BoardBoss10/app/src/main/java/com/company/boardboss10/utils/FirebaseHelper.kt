package com.company.boardboss10.utils

import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

/**
 * Firebase helper for database references
 */
object FirebaseHelper {
    val database: FirebaseDatabase by lazy {
        FirebaseDatabase.getInstance().apply {
            setPersistenceEnabled(true)
        }
    }

    /**
     * Centralized database references
     */
    object References {
        val users: DatabaseReference
            get() = database.getReference("users")

        val questions: DatabaseReference
            get() = database.getReference("questions")

        val rooms: DatabaseReference
            get() = database.getReference("rooms")

        val results: DatabaseReference
            get() = database.getReference("results")

        val dailyChallenges: DatabaseReference
            get() = database.getReference("dailyChallenges")

        val leaderboards: DatabaseReference
            get() = database.getReference("leaderboards")
    }
}
