package com.company.boardboss10.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.company.boardboss10.databinding.FragmentHomeBinding
import com.company.boardboss10.ui.QuizActivity
import com.company.boardboss10.utils.PreferencesManager

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefsManager: PreferencesManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        prefsManager = PreferencesManager(requireContext())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvWelcome.text = "Welcome, ${prefsManager.username}!"
        binding.tvLocation.text = "📍 ${prefsManager.location}"

        binding.btnQuickBattle.setOnClickListener {
            startQuickBattle()
        }
    }

    private fun startQuickBattle() {
        val intent = Intent(requireContext(), QuizActivity::class.java).apply {
            putExtra("ROOM_ID", "quick_${System.currentTimeMillis()}")
            putExtra("SUBJECT", "Mixed")
            putExtra("TIMER_DURATION", 30)
            putExtra("QUESTION_COUNT", 10)
        }
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
