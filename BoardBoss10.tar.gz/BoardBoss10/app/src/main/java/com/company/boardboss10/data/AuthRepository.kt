package com.company.boardboss10.data

import com.company.boardboss10.models.User
import com.company.boardboss10.utils.FirebaseHelper
import com.google.firebase.database.*
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Repository for authentication and user management
 * Admin detection: username "Anjani" (case-insensitive)
 */
class AuthRepository {
    private val database = FirebaseHelper.database
    private val usersRef = FirebaseHelper.References.users

    /**
     * Sign in with username and location
     * Creates new user if doesn't exist, or retrieves existing user
     */
    suspend fun signInWithUsername(username: String, location: String): Result<User> {
        return try {
            // Check if user already exists
            val snapshot = usersRef
                .orderByChild("username")
                .equalTo(username)
                .get()
                .await()

            val user = if (snapshot.exists()) {
                // Existing user - get first match
                val userData = snapshot.children.first()
                val existingUser = userData.getValue(User::class.java)!!

                // Update last active timestamp
                usersRef.child(existingUser.userId).child("lastActive")
                    .setValue(System.currentTimeMillis())

                existingUser
            } else {
                // New user - create account
                val userId = usersRef.push().key!!
                val isAdmin = username.equals("Anjani", ignoreCase = true)

                val newUser = User(
                    userId = userId,
                    username = username,
                    isAdmin = isAdmin,
                    location = location,
                    educationalLevel = "CBSE Class 10"
                )

                usersRef.child(userId).setValue(newUser).await()
                newUser
            }

            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get user by ID
     */
    suspend fun getUserById(userId: String): Result<User> {
        return try {
            val snapshot = usersRef.child(userId).get().await()

            if (snapshot.exists()) {
                val user = snapshot.getValue(User::class.java)!!
                Result.success(user)
            } else {
                Result.failure(Exception("User not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Update user statistics
     */
    suspend fun updateUserStats(
        userId: String,
        scoreIncrement: Int,
        subject: String,
        correctAnswers: Int,
        totalQuestions: Int
    ): Result<Unit> {
        return try {
            val updates = mutableMapOf<String, Any>()

            // Increment total score
            usersRef.child(userId).child("totalScore")
                .setValue(ServerValue.increment(scoreIncrement.toLong()))

            // Increment subject-specific score
            val subjectField = when (subject.lowercase()) {
                "maths" -> "mathsScore"
                "science" -> "scienceScore"
                "sst", "social science" -> "sstScore"
                "english" -> "englishScore"
                "hindi" -> "hindiScore"
                else -> null
            }

            subjectField?.let {
                usersRef.child(userId).child(it)
                    .setValue(ServerValue.increment(scoreIncrement.toLong()))
            }

            // Update game statistics
            usersRef.child(userId).child("gamesPlayed")
                .setValue(ServerValue.increment(1))
            usersRef.child(userId).child("questionsAnswered")
                .setValue(ServerValue.increment(totalQuestions.toLong()))
            usersRef.child(userId).child("correctAnswers")
                .setValue(ServerValue.increment(correctAnswers.toLong()))
            usersRef.child(userId).child("lastActive")
                .setValue(System.currentTimeMillis())

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get all users (admin only)
     */
    suspend fun getAllUsers(): Result<List<User>> {
        return try {
            val snapshot = usersRef.get().await()
            val users = mutableListOf<User>()

            snapshot.children.forEach { child ->
                child.getValue(User::class.java)?.let { users.add(it) }
            }

            Result.success(users.sortedByDescending { it.totalScore })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
