package com.company.boardboss10.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.company.boardboss10.databinding.ActivityAdminPanelBinding
import com.company.boardboss10.data.AdminRepository
import com.company.boardboss10.models.Question
import com.company.boardboss10.utils.Utils
import kotlinx.coroutines.launch

/**
 * Admin Panel Activity
 * Only accessible by admin user: Anjani
 */
class AdminPanelActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminPanelBinding
    private lateinit var adminRepository: AdminRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminPanelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adminRepository = AdminRepository()

        setupUI()
        loadStats()
    }

    private fun setupUI() {
        binding.btnLoadSampleQuestions.setOnClickListener {
            loadSampleQuestions()
        }

        binding.btnViewQuestions.setOnClickListener {
            viewAllQuestions()
        }

        binding.btnViewUsers.setOnClickListener {
            viewAllUsers()
        }
    }

    private fun loadStats() {
        lifecycleScope.launch {
            adminRepository.getAppStatistics().onSuccess { stats ->
                binding.tvTotalUsers.text = "Total Users: ${stats["totalUsers"]}"
                binding.tvTotalQuestions.text = "Total Questions: ${stats["totalQuestions"]}"
                binding.tvTotalQuizzes.text = "Total Quizzes: ${stats["totalQuizzes"]}"
                binding.tvActiveUsers.text = "Active Users: ${stats["activeUsers"]}"
            }
        }
    }

    private fun getSampleQuestions(): List<Question> {
        return listOf(
            // Maths Questions
            Question(
                subject = "Maths",
                chapter = "Algebra",
                questionText = "Solve for x: 2x + 5 = 15",
                options = listOf("x = 5", "x = 10", "x = 7", "x = 3"),
                correctAnswer = 0,
                difficulty = "Easy",
                explanation = "Subtract 5 from both sides: 2x = 10, then divide by 2: x = 5",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Maths",
                chapter = "Geometry",
                questionText = "What is the sum of angles in a triangle?",
                options = listOf("90°", "180°", "360°", "270°"),
                correctAnswer = 1,
                difficulty = "Easy",
                explanation = "The sum of all interior angles in any triangle is always 180°",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Maths",
                chapter = "Trigonometry",
                questionText = "What is the value of sin 90°?",
                options = listOf("0", "1", "0.5", "√3/2"),
                correctAnswer = 1,
                difficulty = "Medium",
                explanation = "sin 90° = 1",
                points = 10,
                createdBy = "Anjani"
            ),

            // Science Questions
            Question(
                subject = "Science",
                chapter = "Physics",
                questionText = "What is the SI unit of force?",
                options = listOf("Joule", "Newton", "Watt", "Pascal"),
                correctAnswer = 1,
                difficulty = "Easy",
                explanation = "Newton (N) is the SI unit of force, named after Sir Isaac Newton",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Science",
                chapter = "Chemistry",
                questionText = "What is the chemical formula of water?",
                options = listOf("H2O", "CO2", "O2", "H2O2"),
                correctAnswer = 0,
                difficulty = "Easy",
                explanation = "Water is composed of 2 hydrogen atoms and 1 oxygen atom: H2O",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Science",
                chapter = "Biology",
                questionText = "Which organ pumps blood in the human body?",
                options = listOf("Liver", "Kidney", "Heart", "Lungs"),
                correctAnswer = 2,
                difficulty = "Easy",
                explanation = "The heart is responsible for pumping blood throughout the body",
                points = 10,
                createdBy = "Anjani"
            ),

            // SST Questions
            Question(
                subject = "SST",
                chapter = "History",
                questionText = "Who was the first Prime Minister of India?",
                options = listOf("Mahatma Gandhi", "Jawaharlal Nehru", "Sardar Patel", "Dr. Rajendra Prasad"),
                correctAnswer = 1,
                difficulty = "Easy",
                explanation = "Jawaharlal Nehru was the first Prime Minister of India from 1947 to 1964",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "SST",
                chapter = "Geography",
                questionText = "Which is the longest river in India?",
                options = listOf("Yamuna", "Ganga", "Brahmaputra", "Godavari"),
                correctAnswer = 1,
                difficulty = "Medium",
                explanation = "The Ganga (Ganges) is the longest river in India at 2,525 km",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "SST",
                chapter = "Civics",
                questionText = "How many fundamental rights are there in the Indian Constitution?",
                options = listOf("5", "6", "7", "8"),
                correctAnswer = 1,
                difficulty = "Medium",
                explanation = "There are 6 fundamental rights in the Indian Constitution",
                points = 10,
                createdBy = "Anjani"
            ),

            // English Questions
            Question(
                subject = "English",
                chapter = "Grammar",
                questionText = "Which is the correct plural form of 'child'?",
                options = listOf("childs", "childes", "children", "childrens"),
                correctAnswer = 2,
                difficulty = "Easy",
                explanation = "The irregular plural of 'child' is 'children'",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "English",
                chapter = "Vocabulary",
                questionText = "What is the synonym of 'happy'?",
                options = listOf("Sad", "Joyful", "Angry", "Tired"),
                correctAnswer = 1,
                difficulty = "Easy",
                explanation = "Joyful means full of joy, which is synonymous with happy",
                points = 10,
                createdBy = "Anjani"
            ),

            // Hindi Questions
            Question(
                subject = "Hindi",
                chapter = "व्याकरण",
                questionText = "'लड़का' शब्द का बहुवचन क्या है?",
                options = listOf("लड़के", "लड़को", "लड़कों", "लड़काएं"),
                correctAnswer = 0,
                difficulty = "Easy",
                explanation = "'लड़का' का बहुवचन 'लड़के' होता है",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Hindi",
                chapter = "साहित्य",
                questionText = "रामचरितमानस के लेखक कौन हैं?",
                options = listOf("कबीर", "तुलसीदास", "सूरदास", "मीराबाई"),
                correctAnswer = 1,
                difficulty = "Medium",
                explanation = "रामचरितमानस की रचना गोस्वामी तुलसीदास जी ने की थी",
                points = 10,
                createdBy = "Anjani"
            ),

            // Additional Mixed Questions
            Question(
                subject = "Maths",
                chapter = "Arithmetic",
                questionText = "What is 15% of 200?",
                options = listOf("20", "25", "30", "35"),
                correctAnswer = 2,
                difficulty = "Medium",
                explanation = "15% of 200 = (15/100) × 200 = 30",
                points = 10,
                createdBy = "Anjani"
            ),
            Question(
                subject = "Science",
                chapter = "Physics",
                questionText = "What is the speed of light in vacuum?",
                options = listOf("3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10⁷ m/s", "3 × 10⁹ m/s"),
                correctAnswer = 0,
                difficulty = "Hard",
                explanation = "The speed of light in vacuum is approximately 3 × 10⁸ m/s",
                points = 10,
                createdBy = "Anjani"
            )
        )
    }

    private fun loadSampleQuestions() {
        showLoading(true)

        lifecycleScope.launch {
            val sampleQuestions = getSampleQuestions()

            adminRepository.bulkAddQuestions(sampleQuestions).onSuccess { count ->
                showLoading(false)
                Utils.showToast(this@AdminPanelActivity, "$count sample questions loaded successfully!")
                loadStats()
            }.onFailure { e ->
                showLoading(false)
                Utils.showToast(this@AdminPanelActivity, "Failed to load questions: ${e.message}")
            }
        }
    }

    private fun viewAllQuestions() {
        showLoading(true)

        lifecycleScope.launch {
            adminRepository.getAllQuestions().onSuccess { questions ->
                showLoading(false)

                val questionList = questions.joinToString("\n\n") {
                    "${Utils.getSubjectEmoji(it.subject)} ${it.subject} - ${it.questionText}"
                }

                AlertDialog.Builder(this@AdminPanelActivity)
                    .setTitle("All Questions (${questions.size})")
                    .setMessage(questionList.ifEmpty { "No questions available" })
                    .setPositiveButton("OK", null)
                    .show()
            }.onFailure { e ->
                showLoading(false)
                Utils.showToast(this@AdminPanelActivity, "Failed to load questions: ${e.message}")
            }
        }
    }

    private fun viewAllUsers() {
        showLoading(true)

        lifecycleScope.launch {
            adminRepository.getAllUsers().onSuccess { users ->
                showLoading(false)

                val userList = users.joinToString("\n") {
                    "${it.username} (${it.location}) - Score: ${it.totalScore}"
                }

                AlertDialog.Builder(this@AdminPanelActivity)
                    .setTitle("All Users (${users.size})")
                    .setMessage(userList.ifEmpty { "No users found" })
                    .setPositiveButton("OK", null)
                    .show()
            }.onFailure { e ->
                showLoading(false)
                Utils.showToast(this@AdminPanelActivity, "Failed to load users: ${e.message}")
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
    }
}
