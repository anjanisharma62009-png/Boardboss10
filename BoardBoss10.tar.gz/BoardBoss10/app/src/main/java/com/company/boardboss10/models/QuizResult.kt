package com.company.boardboss10.models

/**
 * Quiz result model for tracking individual performance
 */
data class QuizResult(
    val resultId: String = "",
    val userId: String = "",
    val username: String = "",
    val roomId: String = "",
    val subject: String = "",

    // Performance metrics
    val score: Int = 0,
    val totalQuestions: Int = 0,
    val correctAnswers: Int = 0,
    val wrongAnswers: Int = 0,
    val accuracy: Double = 0.0, // Percentage

    // Detailed answers: questionId -> selectedAnswer
    val answers: Map<String, Int> = emptyMap(),
    val timeSpent: Map<String, Long> = emptyMap(), // questionId -> milliseconds

    // Ranking
    val rank: Int = 0,
    val completedAt: Long = System.currentTimeMillis()
) {
    fun calculateAccuracy(): Double {
        return if (totalQuestions > 0) {
            (correctAnswers.toDouble() / totalQuestions) * 100
        } else 0.0
    }
}
