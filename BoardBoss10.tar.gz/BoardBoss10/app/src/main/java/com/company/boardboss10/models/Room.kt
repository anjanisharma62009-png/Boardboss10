package com.company.boardboss10.models

/**
 * Room (Quiz Battle) data model
 * Supports multiplayer quiz battles with configurable settings
 */
data class Room(
    val roomId: String = "",
    val roomCode: String = "", // 6-digit code for joining
    val roomName: String = "",
    val hostId: String = "", // User who created the room
    val hostName: String = "",
    val subject: String = "", // Subject for this quiz
    val difficulty: String = "Medium",

    // Player management
    val players: List<String> = emptyList(), // List of userIds
    val playerNames: Map<String, String> = emptyMap(), // userId -> username
    val blockedUsers: List<String> = emptyList(),
    val maxPlayers: Int = 10,

    // Room settings
    val timerDuration: Int = 30, // Seconds per question
    val questionCount: Int = 10, // Questions per quiz
    val status: String = "waiting", // waiting, active, completed

    // Quiz state
    val currentQuestionIndex: Int = 0,
    val questionIds: List<String> = emptyList(),
    val startTime: Long = 0,

    // Timestamps
    val createdAt: Long = System.currentTimeMillis()
) {
    fun isFull(): Boolean = players.size >= maxPlayers
    fun isUserBlocked(userId: String): Boolean = blockedUsers.contains(userId)
}
