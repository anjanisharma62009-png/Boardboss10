package com.company.boardboss10.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Shared preferences manager for app settings
 */
class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "BoardBoss10Prefs"
        private const val KEY_USER_ID = "userId"
        private const val KEY_USERNAME = "username"
        private const val KEY_IS_ADMIN = "isAdmin"
        private const val KEY_IS_LOGGED_IN = "isLoggedIn"
        private const val KEY_THEME_MODE = "themeMode" // "light", "dark", "system"
        private const val KEY_LOCATION = "location"
    }

    var userId: String?
        get() = prefs.getString(KEY_USER_ID, null)
        set(value) = prefs.edit().putString(KEY_USER_ID, value).apply()

    var username: String?
        get() = prefs.getString(KEY_USERNAME, null)
        set(value) = prefs.edit().putString(KEY_USERNAME, value).apply()

    var isAdmin: Boolean
        get() = prefs.getBoolean(KEY_IS_ADMIN, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_ADMIN, value).apply()

    var isLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOGGED_IN, value).apply()

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, "system") ?: "system"
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value).apply()

    var location: String?
        get() = prefs.getString(KEY_LOCATION, null)
        set(value) = prefs.edit().putString(KEY_LOCATION, value).apply()

    /**
     * Save login session
     */
    fun saveLoginSession(userId: String, username: String, isAdmin: Boolean, location: String) {
        prefs.edit().apply {
            putString(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putBoolean(KEY_IS_ADMIN, isAdmin)
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_LOCATION, location)
            apply()
        }
    }

    /**
     * Clear login session (logout)
     */
    fun clearLoginSession() {
        prefs.edit().apply {
            remove(KEY_USER_ID)
            remove(KEY_USERNAME)
            remove(KEY_IS_ADMIN)
            putBoolean(KEY_IS_LOGGED_IN, false)
            remove(KEY_LOCATION)
            apply()
        }
    }

    /**
     * Clear all preferences
     */
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
