package com.company.boardboss10.data

import com.company.boardboss10.models.*
import com.company.boardboss10.utils.FirebaseHelper
import com.company.boardboss10.utils.Utils
import com.google.firebase.database.*
import kotlinx.coroutines.tasks.await

/**
 * Repository for quiz operations
 */
class QuizRepository {
    private val database = FirebaseHelper.database
    private val roomsRef = FirebaseHelper.References.rooms
    private val questionsRef = FirebaseHelper.References.questions
    private val resultsRef = FirebaseHelper.References.results

    /**
     * Create a new quiz room
     */
    suspend fun createRoom(
        hostId: String,
        hostName: String,
        roomName: String,
        subject: String,
        timerDuration: Int,
        questionCount: Int,
        maxPlayers: Int
    ): Result<Room> {
        return try {
            val roomId = roomsRef.push().key!!
            val roomCode = Utils.generateRoomCode()

            // Get random questions for this subject
            val questions = getRandomQuestions(subject, questionCount)
            if (questions.isEmpty()) {
                return Result.failure(Exception("No questions available for $subject"))
            }

            val room = Room(
                roomId = roomId,
                roomCode = roomCode,
                roomName = roomName,
                hostId = hostId,
                hostName = hostName,
                subject = subject,
                players = listOf(hostId),
                playerNames = mapOf(hostId to hostName),
                timerDuration = timerDuration,
                questionCount = questionCount,
                maxPlayers = maxPlayers,
                questionIds = questions.map { it.questionId },
                status = "waiting"
            )

            roomsRef.child(roomId).setValue(room).await()
            Result.success(room)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Join room by code
     */
    suspend fun joinRoomByCode(roomCode: String, userId: String, username: String): Result<Room> {
        return try {
            val snapshot = roomsRef
                .orderByChild("roomCode")
                .equalTo(roomCode)
                .get()
                .await()

            if (!snapshot.exists()) {
                return Result.failure(Exception("Room not found"))
            }

            val roomData = snapshot.children.first()
            val room = roomData.getValue(Room::class.java)!!

            // Validation
            if (room.status != "waiting") {
                return Result.failure(Exception("Room already started"))
            }
            if (room.isFull()) {
                return Result.failure(Exception("Room is full"))
            }
            if (room.isUserBlocked(userId)) {
                return Result.failure(Exception("You are blocked from this room"))
            }
            if (room.players.contains(userId)) {
                return Result.success(room) // Already joined
            }

            // Add player
            val updatedPlayers = room.players + userId
            val updatedPlayerNames = room.playerNames + (userId to username)

            roomsRef.child(room.roomId).child("players").setValue(updatedPlayers).await()
            roomsRef.child(room.roomId).child("playerNames").setValue(updatedPlayerNames).await()

            Result.success(room.copy(players = updatedPlayers, playerNames = updatedPlayerNames))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get random questions for a subject
     */
    suspend fun getRandomQuestions(subject: String, count: Int): List<Question> {
        return try {
            val snapshot = questionsRef
                .orderByChild("subject")
                .equalTo(subject)
                .get()
                .await()

            val questions = mutableListOf<Question>()
            snapshot.children.forEach { child ->
                child.getValue(Question::class.java)?.let {
                    if (it.isActive) questions.add(it)
                }
            }

            questions.shuffled().take(count)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Submit quiz result
     */
    suspend fun submitResult(result: QuizResult): Result<Unit> {
        return try {
            val resultId = resultsRef.push().key!!
            val finalResult = result.copy(
                resultId = resultId,
                accuracy = result.calculateAccuracy()
            )

            resultsRef.child(resultId).setValue(finalResult).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get leaderboard (top scorers)
     */
    suspend fun getLeaderboard(limit: Int = 50): Result<List<User>> {
        return try {
            val authRepo = AuthRepository()
            val users = authRepo.getAllUsers().getOrThrow()
            Result.success(users.take(limit))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get all active rooms
     */
    suspend fun getActiveRooms(): Result<List<Room>> {
        return try {
            val snapshot = roomsRef
                .orderByChild("status")
                .equalTo("waiting")
                .get()
                .await()

            val rooms = mutableListOf<Room>()
            snapshot.children.forEach { child ->
                child.getValue(Room::class.java)?.let { rooms.add(it) }
            }

            Result.success(rooms.sortedByDescending { it.createdAt })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Start room (change status to active)
     */
    suspend fun startRoom(roomId: String): Result<Unit> {
        return try {
            roomsRef.child(roomId).child("status").setValue("active").await()
            roomsRef.child(roomId).child("startTime").setValue(System.currentTimeMillis()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
