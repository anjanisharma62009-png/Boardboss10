package com.company.boardboss10.data

import com.company.boardboss10.models.Question
import com.company.boardboss10.models.User
import com.company.boardboss10.utils.FirebaseHelper
import com.google.firebase.database.*
import kotlinx.coroutines.tasks.await

/**
 * Repository for admin operations
 * Only accessible by users with isAdmin = true
 */
class AdminRepository {
    private val database = FirebaseHelper.database
    private val questionsRef = FirebaseHelper.References.questions
    private val usersRef = FirebaseHelper.References.users

    /**
     * Add a new question
     */
    suspend fun addQuestion(question: Question): Result<String> {
        return try {
            if (!question.isValid()) {
                return Result.failure(Exception("Invalid question data"))
            }

            val questionId = questionsRef.push().key!!
            val newQuestion = question.copy(questionId = questionId)

            questionsRef.child(questionId).setValue(newQuestion).await()
            Result.success(questionId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Bulk add questions
     */
    suspend fun bulkAddQuestions(questions: List<Question>): Result<Int> {
        return try {
            var successCount = 0

            questions.forEach { question ->
                val result = addQuestion(question)
                if (result.isSuccess) successCount++
            }

            Result.success(successCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Update existing question
     */
    suspend fun updateQuestion(questionId: String, updates: Map<String, Any>): Result<Unit> {
        return try {
            questionsRef.child(questionId).updateChildren(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete question
     */
    suspend fun deleteQuestion(questionId: String): Result<Unit> {
        return try {
            questionsRef.child(questionId).removeValue().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get all questions (paginated)
     */
    suspend fun getAllQuestions(): Result<List<Question>> {
        return try {
            val snapshot = questionsRef.get().await()
            val questions = mutableListOf<Question>()

            snapshot.children.forEach { child ->
                child.getValue(Question::class.java)?.let { questions.add(it) }
            }

            Result.success(questions.sortedByDescending { it.createdAt })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get all users
     */
    suspend fun getAllUsers(): Result<List<User>> {
        return try {
            val authRepo = AuthRepository()
            authRepo.getAllUsers()
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Block user from a specific room (admin only)
     */
    suspend fun blockUserFromRoom(roomId: String, userId: String): Result<Unit> {
        return try {
            val roomsRef = FirebaseHelper.References.rooms
            val snapshot = roomsRef.child(roomId).child("blockedUsers").get().await()

            val blockedUsers = snapshot.value as? List<String> ?: emptyList()
            val updatedBlocked = blockedUsers + userId

            roomsRef.child(roomId).child("blockedUsers").setValue(updatedBlocked).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get app statistics (for admin dashboard)
     */
    suspend fun getAppStatistics(): Result<Map<String, Any>> {
        return try {
            val usersSnapshot = usersRef.get().await()
            val questionsSnapshot = questionsRef.get().await()
            val resultsRef = FirebaseHelper.References.results
            val resultsSnapshot = resultsRef.get().await()

            val stats = mapOf(
                "totalUsers" to usersSnapshot.childrenCount,
                "totalQuestions" to questionsSnapshot.childrenCount,
                "totalQuizzes" to resultsSnapshot.childrenCount,
                "activeUsers" to usersSnapshot.children.count {
                    val user = it.getValue(User::class.java)
                    user != null && (System.currentTimeMillis() - user.lastActive) < 7 * 24 * 60 * 60 * 1000
                }
            )

            Result.success(stats)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
