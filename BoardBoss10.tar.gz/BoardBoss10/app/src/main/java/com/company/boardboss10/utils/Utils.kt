package com.company.boardboss10.utils

import android.content.Context
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

/**
 * Utility functions for the app
 */
object Utils {

    /**
     * Generate a random 6-digit room code
     */
    fun generateRoomCode(): String {
        return (100000..999999).random().toString()
    }

    /**
     * Generate random color for user avatar
     */
    fun generateRandomColor(): String {
        val colors = listOf(
            "#FF6B9D", "#C44569", "#FD7272", "#54A0FF",
            "#48DBFB", "#1DD1A1", "#10AC84", "#5F27CD",
            "#FF9FF3", "#FCA5A5", "#FBBF24", "#A78BFA"
        )
        return colors.random()
    }

    /**
     * Calculate score based on time and accuracy
     * Formula: basePoints * (1 + speedBonus) where speedBonus = (timerDuration - timeSpent) / timerDuration
     */
    fun calculateScore(
        isCorrect: Boolean,
        basePoints: Int,
        timeSpent: Long,
        timerDuration: Long
    ): Long {
        if (!isCorrect) return 0

        val speedBonus = ((timerDuration - timeSpent).toFloat() / timerDuration.toFloat())
            .coerceIn(0f, 1f)

        return (basePoints * (1 + speedBonus)).toLong()
    }

    /**
     * Format timestamp to readable date
     */
    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Format time in milliseconds to MM:SS
     */
    fun formatTime(milliseconds: Long): String {
        val seconds = (milliseconds / 1000) % 60
        val minutes = (milliseconds / 1000) / 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    /**
     * Get today's date in yyyy-MM-dd format
     */
    fun getTodayDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    /**
     * Check if username is valid (3-20 characters, alphanumeric and underscore only)
     */
    fun isValidUsername(username: String): Boolean {
        val regex = Regex("^[a-zA-Z0-9_]{3,20}$")
        return username.matches(regex)
    }

    /**
     * Show toast message
     */
    fun showToast(context: Context, message: String, duration: Int = Toast.LENGTH_SHORT) {
        Toast.makeText(context, message, duration).show()
    }

    /**
     * Get subject emoji
     */
    fun getSubjectEmoji(subject: String): String {
        return when (subject) {
            "Maths" -> "🔢"
            "Science" -> "🔬"
            "SST" -> "🌍"
            "English" -> "📚"
            "Hindi" -> "📖"
            else -> "📝"
        }
    }

    /**
     * Get rank suffix (1st, 2nd, 3rd, etc.)
     */
    fun getRankSuffix(rank: Int): String {
        return when {
            rank % 100 in 11..13 -> "${rank}th"
            rank % 10 == 1 -> "${rank}st"
            rank % 10 == 2 -> "${rank}nd"
            rank % 10 == 3 -> "${rank}rd"
            else -> "${rank}th"
        }
    }
}
