package com.company.boardboss10.ui

import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.company.boardboss10.R
import com.company.boardboss10.databinding.ActivityQuizBinding
import com.company.boardboss10.data.QuizRepository
import com.company.boardboss10.data.AuthRepository
import com.company.boardboss10.models.Question
import com.company.boardboss10.models.QuizResult
import com.company.boardboss10.utils.PreferencesManager
import com.company.boardboss10.utils.Utils
import kotlinx.coroutines.launch

/**
 * Quiz Activity with live timer and smart scoring
 * Formula: basePoints * (1 + speedBonus) where speedBonus = (timerDuration - timeSpent) / timerDuration
 */
class QuizActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuizBinding
    private lateinit var quizRepository: QuizRepository
    private lateinit var authRepository: AuthRepository
    private lateinit var prefsManager: PreferencesManager

    private var questions: List<Question> = emptyList()
    private var currentQuestionIndex = 0
    private var timer: CountDownTimer? = null
    private var timerDuration = 30000L // milliseconds
    private var questionStartTime = 0L

    private val answers = mutableMapOf<String, Int>()
    private val timeSpent = mutableMapOf<String, Long>()
    private var totalScore = 0L
    private var correctAnswers = 0

    private lateinit var roomId: String
    private lateinit var subject: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        quizRepository = QuizRepository()
        authRepository = AuthRepository()
        prefsManager = PreferencesManager(this)

        // Get intent extras
        roomId = intent.getStringExtra("ROOM_ID") ?: ""
        subject = intent.getStringExtra("SUBJECT") ?: "Mixed"
        timerDuration = intent.getIntExtra("TIMER_DURATION", 30) * 1000L
        val questionCount = intent.getIntExtra("QUESTION_COUNT", 10)

        setupUI()
        loadQuestions(subject, questionCount)
    }

    private fun setupUI() {
        binding.btnOption1.setOnClickListener { selectAnswer(0) }
        binding.btnOption2.setOnClickListener { selectAnswer(1) }
        binding.btnOption3.setOnClickListener { selectAnswer(2) }
        binding.btnOption4.setOnClickListener { selectAnswer(3) }
    }

    private fun loadQuestions(subject: String, count: Int) {
        showLoading(true)

        lifecycleScope.launch {
            val loadedQuestions = quizRepository.getRandomQuestions(subject, count)
            if (loadedQuestions.isEmpty()) {
                Utils.showToast(this@QuizActivity, "No questions available for $subject")
                finish()
                return@launch
            }

            questions = loadedQuestions
            showLoading(false)
            showQuestion()
        }
    }

    private fun showQuestion() {
        if (currentQuestionIndex >= questions.size) {
            finishQuiz()
            return
        }

        val question = questions[currentQuestionIndex]

        // Update UI
        binding.tvQuestionNumber.text = "Question ${currentQuestionIndex + 1}/${questions.size}"
        binding.tvQuestionText.text = question.questionText
        binding.tvSubject.text = "${Utils.getSubjectEmoji(question.subject)} ${question.subject}"

        // Set options
        val optionButtons = listOf(
            binding.btnOption1,
            binding.btnOption2,
            binding.btnOption3,
            binding.btnOption4
        )

        optionButtons.forEachIndexed { index, button ->
            button.text = question.options.getOrNull(index) ?: ""
            button.isEnabled = true
            button.setBackgroundColor(ContextCompat.getColor(this, R.color.option_default))
        }

        // Update progress
        binding.progressBar.max = questions.size
        binding.progressBar.progress = currentQuestionIndex

        // Start timer
        startTimer()
        questionStartTime = System.currentTimeMillis()
    }

    private fun startTimer() {
        timer?.cancel()

        timer = object : CountDownTimer(timerDuration, 100) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = (millisUntilFinished / 1000).toInt()
                binding.tvTimer.text = "$seconds s"

                // Change color when time is running out
                if (seconds <= 5) {
                    binding.tvTimer.setTextColor(ContextCompat.getColor(this@QuizActivity, android.R.color.holo_red_dark))
                }
            }

            override fun onFinish() {
                handleTimeout()
            }
        }.start()
    }

    private fun selectAnswer(selectedIndex: Int) {
        timer?.cancel()

        val question = questions[currentQuestionIndex]
        val elapsedTime = System.currentTimeMillis() - questionStartTime

        // Record answer
        answers[question.questionId] = selectedIndex
        timeSpent[question.questionId] = elapsedTime

        // Check if correct
        val isCorrect = selectedIndex == question.correctAnswer
        if (isCorrect) {
            correctAnswers++
        }

        // Calculate score with speed bonus
        val score = Utils.calculateScore(isCorrect, question.points, elapsedTime, timerDuration)
        totalScore += score

        // Show feedback
        showAnswerFeedback(selectedIndex, question.correctAnswer, isCorrect)
    }

    private fun showAnswerFeedback(selectedIndex: Int, correctIndex: Int, isCorrect: Boolean) {
        val optionButtons = listOf(binding.btnOption1, binding.btnOption2, binding.btnOption3, binding.btnOption4)

        // Disable all buttons
        optionButtons.forEach { it.isEnabled = false }

        // Highlight correct and selected answers
        optionButtons[correctIndex].setBackgroundColor(
            ContextCompat.getColor(this, android.R.color.holo_green_dark)
        )

        if (!isCorrect) {
            optionButtons[selectedIndex].setBackgroundColor(
                ContextCompat.getColor(this, android.R.color.holo_red_dark)
            )
        }

        // Move to next question after delay
        binding.root.postDelayed({
            currentQuestionIndex++
            showQuestion()
        }, 1500)
    }

    private fun handleTimeout() {
        val question = questions[currentQuestionIndex]
        answers[question.questionId] = -1 // No answer
        timeSpent[question.questionId] = timerDuration

        Utils.showToast(this, "Time's up!")

        binding.root.postDelayed({
            currentQuestionIndex++
            showQuestion()
        }, 1000)
    }

    private fun finishQuiz() {
        timer?.cancel()

        val userId = prefsManager.userId ?: return
        val username = prefsManager.username ?: return

        // Create result
        val result = QuizResult(
            userId = userId,
            username = username,
            roomId = roomId,
            subject = subject,
            score = totalScore.toInt(),
            totalQuestions = questions.size,
            correctAnswers = correctAnswers,
            wrongAnswers = questions.size - correctAnswers,
            answers = answers,
            timeSpent = timeSpent
        )

        // Submit result and update user stats
        lifecycleScope.launch {
            quizRepository.submitResult(result)
            authRepository.updateUserStats(userId, totalScore.toInt(), subject, correctAnswers, questions.size)

            showResultDialog(result)
        }
    }

    private fun showResultDialog(result: QuizResult) {
        AlertDialog.Builder(this)
            .setTitle("Quiz Complete!")
            .setMessage(
                "Score: ${result.score}\n" +
                "Correct: ${result.correctAnswers}/${result.totalQuestions}\n" +
                "Accuracy: ${String.format("%.1f", result.calculateAccuracy())}%"
            )
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}
