package com.company.boardboss10.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.company.boardboss10.databinding.ActivityLoginBinding
import com.company.boardboss10.data.AuthRepository
import com.company.boardboss10.utils.PreferencesManager
import com.company.boardboss10.utils.Utils
import kotlinx.coroutines.launch

/**
 * Login Activity with username and location input
 * Admin detection: username "Anjani" (case-insensitive)
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var authRepository: AuthRepository
    private lateinit var prefsManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        authRepository = AuthRepository()
        prefsManager = PreferencesManager(this)

        // Check if already logged in
        if (prefsManager.isLoggedIn) {
            navigateToMain()
            return
        }

        setupUI()
    }

    private fun setupUI() {
        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val location = binding.etLocation.text.toString().trim()

            if (validateInput(username, location)) {
                loginUser(username, location)
            }
        }
    }

    private fun validateInput(username: String, location: String): Boolean {
        return when {
            username.isEmpty() -> {
                Utils.showToast(this, "Please enter username")
                false
            }
            !Utils.isValidUsername(username) -> {
                Utils.showToast(this, "Username must be 3-20 characters, alphanumeric only")
                false
            }
            location.isEmpty() -> {
                Utils.showToast(this, "Please enter location")
                false
            }
            else -> true
        }
    }

    private fun loginUser(username: String, location: String) {
        showLoading(true)

        lifecycleScope.launch {
            authRepository.signInWithUsername(username, location).onSuccess { user ->
                // Save session
                prefsManager.saveLoginSession(
                    userId = user.userId,
                    username = user.username,
                    isAdmin = user.isAdmin,
                    location = user.location
                )

                Utils.showToast(
                    this@LoginActivity,
                    if (user.isAdmin) "Welcome Admin $username!" else "Welcome $username!"
                )

                navigateToMain()
            }.onFailure { e ->
                showLoading(false)
                Utils.showToast(this@LoginActivity, "Login failed: ${e.message}")
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !show
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
