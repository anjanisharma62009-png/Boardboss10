package com.company.boardboss10.models

/**
 * Daily Challenge model for engagement features
 */
data class DailyChallenge(
    val challengeId: String = "",
    val date: String = "", // YYYY-MM-DD format
    val subject: String = "",
    val title: String = "",
    val description: String = "",

    // Challenge configuration
    val questionIds: List<String> = emptyList(),
    val questionCount: Int = 5,
    val timerDuration: Int = 30,
    val difficulty: String = "Medium",

    // Rewards
    val rewardBadge: String = "",
    val rewardPoints: Int = 50,

    // Participation tracking
    val participants: List<String> = emptyList(), // List of userIds
    val completions: Map<String, Int> = emptyMap(), // userId -> score

    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
