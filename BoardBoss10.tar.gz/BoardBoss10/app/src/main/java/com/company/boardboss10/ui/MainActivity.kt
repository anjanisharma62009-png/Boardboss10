package com.company.boardboss10.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.company.boardboss10.R
import com.company.boardboss10.databinding.ActivityMainBinding
import com.company.boardboss10.utils.PreferencesManager

/**
 * Main Activity with bottom navigation
 * Contains Home, Rooms, Leaderboard, Profile fragments
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefsManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefsManager = PreferencesManager(this)

        // Check login
        if (!prefsManager.isLoggedIn) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setupUI()
        applyTheme()
    }

    private fun setupUI() {
        // Setup navigation
        val navController = findNavController(R.id.nav_host_fragment)
        binding.bottomNav.setupWithNavController(navController)

        // Show admin FAB if user is admin
        if (prefsManager.isAdmin) {
            binding.fabAdmin.visibility = View.VISIBLE
            binding.fabAdmin.setOnClickListener {
                startActivity(Intent(this, AdminPanelActivity::class.java))
            }
        } else {
            binding.fabAdmin.visibility = View.GONE
        }
    }

    private fun applyTheme() {
        when (prefsManager.themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }
}
