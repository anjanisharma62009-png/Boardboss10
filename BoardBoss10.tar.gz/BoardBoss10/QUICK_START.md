# ⚡ Quick Start Guide - BoardBoss10

## 5-Minute Setup

### Step 1: Firebase Setup (2 minutes)

1. **Go to Firebase Console**: https://console.firebase.google.com/
2. **Create Project**: Click "Add project" → Name: "BoardBoss10"
3. **Add Android App**:
   - Package name: `com.company.boardboss10`
   - Download `google-services.json`
   - Skip other steps
4. **Enable Services**:
   - Authentication → Anonymous → Enable
   - Realtime Database → Create → Test mode

### Step 2: Add Config File (30 seconds)

```bash
# Copy google-services.json to app/ folder
cp ~/Downloads/google-services.json BoardBoss10/app/
```

### Step 3: Build & Run (2 minutes)

```bash
cd BoardBoss10
./gradlew installDebug
```

OR open in Android Studio and click Run ▶️

---

## First Launch Checklist

✅ **Step 1**: Launch app
✅ **Step 2**: Login as "Anjani" (admin)
✅ **Step 3**: Tap floating admin button
✅ **Step 4**: Click "Load Sample Questions"
✅ **Step 5**: Start "Quick Battle" from home screen

---

## Common Issues

### ❌ Build fails with "google-services.json not found"
**Solution**: Download from Firebase Console → Project Settings → Your Apps → google-services.json

### ❌ App crashes on quiz start
**Solution**: Load sample questions from admin panel first

### ❌ "Permission denied" on database
**Solution**: Firebase Console → Realtime Database → Rules → Change to test mode:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

---

## Testing Checklist

- [ ] Login with username "Anjani"
- [ ] Admin button visible
- [ ] Load sample questions successful
- [ ] Start quick battle works
- [ ] Questions display correctly
- [ ] Timer counts down
- [ ] Score calculation works
- [ ] Results show properly

---

## Default Settings

| Setting | Value |
|---------|-------|
| Admin Username | Anjani |
| Timer Duration | 30 seconds |
| Questions Per Quiz | 10 |
| Max Players | 10 |
| Primary Color | #6B4EFF |
| Dark Mode | Enabled |
| Daily Challenges | Enabled |
| Leaderboards | Enabled |

---

**Ready to quiz! 🎯**
